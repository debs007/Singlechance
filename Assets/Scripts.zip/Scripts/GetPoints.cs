﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;
using TMPro;

public class GetPoints : MonoBehaviour
{
    public static GetPoints getPoints;
    //public Image[] ChangableSprites;
    int ChipValue,MainPlayValue = 0;
    private Quaternion _targetRotation = Quaternion.identity;
    public DetectNumber detect;
    public Vector3[] NumbersPositions;
    public bool AllowRotation = false,ChipSelected = false,SetPoisitionNow = false;
    public GameObject NumberPanel;
    GameObject _GlobalChipHolder;
    public List<int> baitList = new List<int>();
    [SerializeField]
    [Range(0f, 10000f)]
    float _Speed = 500f;
    float _SpeedTs = 90f;
    public GameObject BaitNumberPanelParent;
    float time = 0;
    public Text PlayPoints,MainPoints,Wintext;
    Coroutine InstanceHolder;
    bool WinDeclared = false;
    public static bool Is_Spinning = false;
    public int tokensWon,won_on_number;
    public int multiplication = 9;
    public GameObject front_msg_text,DoubleTextPlay,DoubleTextWin;
    public RectTransform fmsg_parent;
    Color col;
    Coroutine resultCrt;
    float startRotation = 0;
    float endRotation = 0;

    public static string gotNumber;
    [SerializeField]
    public List<int> repeat = new List<int>();
    public Button[] allButtonsToDisable;
    //static Button[] allButtonsToDisableStatic;
    public static bool allowBait = true;

    public Button[] odds;
    public Button[] evens;
    public GameObject[] allNumbersButton;

    public GameObject NumberDrawPanel;
    public Dictionary<string, int> numberValues = new Dictionary<string, int>();
    public int LastBait = 0;
    public TextMeshProUGUI XNumber;
    public Animator NAnim;
    public TextMeshProUGUI NNumber;
    public GameObject[] allToDisable;
    public GameObject youWinMsg;
    public Text YouWinText;
    public GameObject Glow;
    public Text MyName;

    public Transform allLightHolder;
    public GameObject BlackLayover;
    public AudioSource SpinWheelAudio,winaudio;
    public Image xNum;
    public Sprite[] xNumns;
    public int thZero = 0, thOne = 0, thTwo = 0, thThree = 0, thFour = 0, thFive = 0, thSix = 0, thSeven = 0, thEight = 0, thNine = 0;

    public Transform pointValuesText;
    
    // Start is called before the first frame update
    void Start()
    {
       // NumbersPositions = ResultView.resultView.NumberPositions;
        // allowBait = true;
        getPoints = this;
        col = PlayPoints.color;

#if UNITY_ANDROID || UNITY_IOS
        foreach(GameObject obj in allToDisable)
        {
            obj.SetActive(false);
        }
#endif

        //allButtonsToDisableStatic = allButtonsToDisable;
        

    }

    private void OnGUI()
    {
        

        
    }

    public void DisableAll()
    {
        foreach (Button btn in allButtonsToDisable)
        {
            if (allowBait == false)
                btn.interactable = false;
            else
                btn.interactable = true;
        }
    }

    bool WinHit = false;
    /// <summary>
    /// This sentstate variable makes sure when odds or evens or random number are selected at the same time , they don't call update bet instant funtion every time when the button is clicked
    /// </summary>
    bool sentState = true;
    public void SelectOdds()
    {
        if (!allowBait)
        {
            return;
        }
        //Clear(NumberDrawPanel);
        sentState = false;
        foreach(Button btn in odds)
        {
            btn.onClick.Invoke();
        }
        sentState = true;
        GameController.instance.UpdateBetInstant(0, 0);
    }
    public void SelectEvens()
    {
        if (!allowBait)
        {
            return;
        }
        // Clear(NumberDrawPanel);
        sentState = false;
        foreach (Button btn in evens)
        {
            btn.onClick.Invoke();
        }

        sentState = true;
        GameController.instance.UpdateBetInstant(0, 0);
    }

    public void SelectRandom(int lim)
    {
        if (!allowBait)
        {
            return;
        }
        Clear(NumberDrawPanel);
        List<int> usedNumbers = new List<int>();
        sentState = false;
        for(int i=0;i< lim;)
        {
            int slectedRand = UnityEngine.Random.Range(0, allNumbersButton.Length);

            if(!usedNumbers.Contains(slectedRand))
            {
                GameObject btn = allNumbersButton[slectedRand];
                btn.GetComponent<Button>().onClick.Invoke();
                usedNumbers.Add(slectedRand);
                i++;
            }

           
        }

        sentState = true;
        GameController.instance.UpdateBetInstant(0, 0);
    }

    public void PrintFromButton()
    {
        int total = thZero + thOne + thTwo + thThree + thFour + thFive + thSix + thSeven + thEight + thNine;
        string dataSet1 = "Session:" + Constants.sessionData.sessionNum + "\nDate-Time:" + DateTime.Now.ToString() + "\n\nZero : " + thZero + "\nOne : " + thOne + "\nTwo : " + thTwo + "\nThree : " + thThree + "\nFour : " + thFour + "\nFive : " + thFive + "\nSix : " + thSix + "\nSeven : " + thSeven + "\nEight : " + thEight + "\nNine : " + thNine + "\n-------------\nTotal: " + total;
        string header = "";
        string[] data = new string[2];
        data[0] = dataSet1;
        data[1] = header;
        PrintNow.Instance.StartPrint(data);

        thZero = 0; thOne = 0; thTwo = 0; thThree = 0; thFour = 0; thFive = 0; thSix = 0; thSeven = 0; thEight = 0; thNine = 0;

        foreach (Transform trn in pointValuesText)
        {
            trn.GetChild(0).GetChild(0).gameObject.GetComponent<Text>().text = "0";
        }
    }
    // Update is called once per frame
    void Update()
    {


        //if (Convert.ToInt32(PlayPoints.text) > Convert.ToInt32(MainPoints.text))
        //{
        //    PlayPoints.color = Color.red;
        //}
        //else
        //    PlayPoints.color = col;

        if (Input.GetKeyDown(KeyCode.P))
        {
            int total = thZero + thOne + thTwo + thThree + thFour + thFive + thSix + thSeven + thEight + thNine;
            string dataSet1 = "Session :  " + Constants.sessionData.sessionNum+"\nDate Time : "+DateTime.Now.ToString()+"\n\nZero : " + thZero + "\nOne : " + thOne + "\nTwo : " + thTwo + "\nThree : " + thThree + "\nFour : " + thFour + "\nFive : " + thFive + "\nSix : " + thSix + "\nSeven : " + thSeven + "\nEight : " + thEight + "\nNine : " + thNine+"\n-------------\nTotal: "+total;
            string header = "";
            string[] data = new string[2];
            data[0] = dataSet1;
            data[1] = header;
            PrintNow.Instance.StartPrint(data);

            thZero = 0; thOne = 0; thTwo = 0; thThree = 0; thFour = 0; thFive = 0; thSix = 0; thSeven = 0; thEight = 0; thNine = 0;

            foreach (Transform trn in pointValuesText)
            {
                trn.GetChild(0).GetChild(0).gameObject.GetComponent<Text>().text = "0";
            }
        }

        if (GameController.has_network)
        {


            if (WinDeclared)
            {
                WinDeclared = false;
                SetPoisitionNow = false;
                StopCoroutine(InstanceHolder);
            }
            //        Debug.Log(NumberPanel.GetComponent<Rigidbody2D>().angularVelocity);
            if (AllowRotation)
            {
                SetPoisitionNow = false;
                WinHit = false;
                detect.StopDetecting = false;
                time += Time.deltaTime;
                //Debug.Log(time);
                NumberPanel.transform.Rotate(new Vector3(0, 0, -1f) * _Speed * Time.deltaTime);

                if (time >= 7.0f)
                {
                    Debug.Log("Speed is: "+_Speed);
                    _Speed -= 1f;
                }
                else if (time >= 5.0f)
                {
                    if(time == 5f)
                    {
                       // print("Calling win number");

                    }
                    _Speed -= 1f;
                    Debug.Log("Speed is: "+_Speed);
                }


                if (_Speed <= 100f)
                {
                    Debug.Log("The Speed have been set to lowest");
                    AllowRotation = false;
                    SetPoisitionNow = true;
                    //_targetRotation = Quaternion.Euler(NumbersPositions[0]);
                    // NumberPanel.transform.rotation = _targetRotation;
                    
                    endRotation = _targetRotation.eulerAngles.z;
                    startRotation = NumberPanel.transform.eulerAngles.z;
                   // InstanceHolder = StartCoroutine(GetWinNumber());
                }

            }
            if (SetPoisitionNow)
            {
                //detect.StopDetecting = true;
                //endRotation += _SpeedTs * Time.deltaTime;
                ////NumberPanel.transform.rotation = Quaternion.Euler(0f,0f, Mathf.Lerp(NumberPanel.transform.rotation.z, _targetRotation.z, _SpeedTs * Time.deltaTime));

                //float eulerRot = Mathf.Lerp(startRotation, endRotation, .5f);
                //NumberPanel.transform.eulerAngles = new Vector3(0, 0, eulerRot);
                if (detect.LastObject.name != gotNumber && gotNumber != "")
                {
                   // print("Not zero");
                    NumberPanel.transform.Rotate(new Vector3(0, 0, -1f) * _Speed * Time.deltaTime);
                }

                if (detect.LastObject.name == gotNumber && gotNumber != "")
                {
                    _targetRotation = Quaternion.Euler(NumbersPositions[Convert.ToInt32(gotNumber)]);
                    NumberPanel.transform.rotation = Quaternion.Lerp(NumberPanel.transform.rotation, _targetRotation, 1f * Time.deltaTime);

                    //if(NumberPanel.transform.rotation.z != _targetRotation.z)
                    //{
                    //    NumberPanel.transform.Rotate(new Vector3(0, 0, -1f) * _Speed * Time.deltaTime);
                    //}


                    if (!WinHit)
                    {

                        if(Xcrt !=null)
                        {
                            StopCoroutine(Xcrt);
                            Xcrt = null;
                        }

                        if (GameController.selectedXVal == 0)
                        {
                            GameController.selectedXVal = 1;
                            //XNumber.text = "N";
                            xNum.sprite = xNumns[GameController.selectedXVal];
                        }
                        else
                        {
                            //XNumber.text = GameController.selectedXVal + "X";
                            xNum.sprite = xNumns[GameController.selectedXVal];
                        }

                            Xcrt = null;
                        
                        WinHit = true;
                        InstanceHolder = StartCoroutine(GetWinNumber());
                    }
                    
                }


                //if (detect.LastObject.name.Equals("0"))
                //{
                //    //Debug.Log("Rotating for zero");
                //    _targetRotation = Quaternion.Euler(NumbersPositions[0]);
                //    NumberPanel.transform.rotation = Quaternion.Lerp(NumberPanel.transform.rotation, _targetRotation, _SpeedTs * Time.deltaTime);
                //}
                //else if (detect.LastObject.name.Equals("1"))
                //{
                //    // Debug.Log("Rotating for one");
                //    _targetRotation = Quaternion.Euler(NumbersPositions[1]);
                //    NumberPanel.transform.rotation = Quaternion.Lerp(NumberPanel.transform.rotation, _targetRotation, _SpeedTs * Time.deltaTime);
                //}
                //else if (detect.LastObject.name.Equals("2"))
                //{
                //    // Debug.Log("Rotating for two");
                //    _targetRotation = Quaternion.Euler(NumbersPositions[2]);
                //    NumberPanel.transform.rotation = Quaternion.Lerp(NumberPanel.transform.rotation, _targetRotation, _SpeedTs * Time.deltaTime);
                //}
                //else if (detect.LastObject.name.Equals("3"))
                //{
                //    //Debug.Log("Rotating for thr");
                //    _targetRotation = Quaternion.Euler(NumbersPositions[3]);
                //    NumberPanel.transform.rotation = Quaternion.Lerp(NumberPanel.transform.rotation, _targetRotation, _SpeedTs * Time.deltaTime);
                //}
                //else if (detect.LastObject.name.Equals("4"))
                //{
                //    //  Debug.Log("Rotating for for");
                //    _targetRotation = Quaternion.Euler(NumbersPositions[4]);
                //    NumberPanel.transform.rotation = Quaternion.Lerp(NumberPanel.transform.rotation, _targetRotation, _SpeedTs * Time.deltaTime);
                //}
                //else if (detect.LastObject.name.Equals("5"))
                //{
                //    // Debug.Log("Rotating for fif");
                //    _targetRotation = Quaternion.Euler(NumbersPositions[5]);
                //    NumberPanel.transform.rotation = Quaternion.Lerp(NumberPanel.transform.rotation, _targetRotation, _SpeedTs * Time.deltaTime);
                //}
                //else if (detect.LastObject.name.Equals("6"))
                //{
                //    //  Debug.Log("Rotating for six");
                //    _targetRotation = Quaternion.Euler(NumbersPositions[6]);
                //    NumberPanel.transform.rotation = Quaternion.Lerp(NumberPanel.transform.rotation, _targetRotation, _SpeedTs * Time.deltaTime);
                //}
                //else if (detect.LastObject.name.Equals("7"))
                //{
                //    //                    Debug.Log("Rotating for sev");
                //    _targetRotation = Quaternion.Euler(NumbersPositions[7]);
                //    NumberPanel.transform.rotation = Quaternion.Lerp(NumberPanel.transform.rotation, _targetRotation, _SpeedTs * Time.deltaTime);
                //}
                //else if (detect.LastObject.name.Equals("8"))
                //{
                //    // Debug.Log("Rotating for eit");
                //    _targetRotation = Quaternion.Euler(NumbersPositions[8]);
                //    NumberPanel.transform.rotation = Quaternion.Lerp(NumberPanel.transform.rotation, _targetRotation, _SpeedTs * Time.deltaTime);
                //}
                //else if (detect.LastObject.name.Equals("9"))
                //{
                //    //Debug.Log("Rotating for nine");
                //    _targetRotation = Quaternion.Euler(NumbersPositions[9]);
                //    NumberPanel.transform.rotation = Quaternion.Lerp(NumberPanel.transform.rotation, _targetRotation, _SpeedTs * Time.deltaTime);
                //}
                //NumberPanel.transform.Rotate(new Vector3(0,0,0));
            }
        }
    }

    private bool ClearVal = false;
    public void AllowNumberClear()
    {
        ClearVal = true;
    }

    public void ClearNumber(GameObject num)
    {
        if (!allowBait)
        {
            return;
        }
        int amountToSubstact = 0;
        num.transform.GetChild(0).gameObject.GetComponent<Text>().text = "0";
        if (num.name == "0")
        {
            amountToSubstact = NumberPoints.zero;
            NumberPoints.zero = 0;
            thZero = 0;
            baitList.Remove(0);
        }
        
        if (num.name == "1")
        {
            amountToSubstact = NumberPoints.one;
            NumberPoints.one = 0;
            baitList.Remove(1);
            thOne = 0;
        }
        if (num.name == "2")
        {
            amountToSubstact = NumberPoints.two;
            NumberPoints.two = 0;
            baitList.Remove(2);
            thTwo = 0;
        }
        if (num.name == "3")
        {
            amountToSubstact = NumberPoints.three;
            NumberPoints.three = 0;
            baitList.Remove(3);
            thThree = 0;
        }
        if (num.name == "4")
        {
            amountToSubstact = NumberPoints.four;
            NumberPoints.four = 0;
            baitList.Remove(4);
            thFour = 0;
        }
        if (num.name == "5")
        {
            amountToSubstact = NumberPoints.five;
            NumberPoints.five = 0;
            baitList.Remove(5);
            thFive = 0;
        }
        if (num.name == "6")
        {
            amountToSubstact = NumberPoints.six;
            NumberPoints.six = 0;
            baitList.Remove(6);
            thSix = 0;
        }
        if (num.name == "7")
        {
            amountToSubstact = NumberPoints.seven;
            NumberPoints.seven = 0;
            baitList.Remove(7);
            thSeven = 0;
        }
        if (num.name == "8")
        {
            amountToSubstact = NumberPoints.eight;
            NumberPoints.eight = 0;
            baitList.Remove(8);
            thEight = 0;
        }
        if (num.name == "9")
        {
            amountToSubstact = NumberPoints.nine;
            NumberPoints.nine = 0;
            baitList.Remove(9);
            thNine = 0;
        }

        PlayPoints.text = (Convert.ToInt32(PlayPoints.text) - amountToSubstact).ToString();
        MainPoints.text = (Convert.ToInt32(MainPoints.text) + amountToSubstact).ToString();
    }
    int prev0, prev1, prev2, prev3, prev4, prev5, prev6, prev7, prev8, prev9;
    public void MakeDouble()
    {
        if (!allowBait)
        {
            return;
        }
        if (Convert.ToInt32(PlayPoints.text) <= Convert.ToInt32(MainPoints.text))
        {
            multiplication = 9;
            //DoubleTextWin.SetActive(true);
            //DoubleTextPlay.SetActive(true);
            MainPoints.text = (Convert.ToInt32(MainPoints.text) - (Convert.ToInt32(PlayPoints.text))).ToString();
            PlayPoints.text = (Convert.ToInt32(PlayPoints.text) * 2).ToString();

            

            foreach (GameObject num in allNumbersButton)
            {
                if(num.transform.GetChild(0).GetChild(0).GetComponent<Text>().text != "0")
                {
                    if(baitList.Contains(Convert.ToInt32(num.name)))
                    {
                        if(num.name == "0")
                        {
                            prev0 = NumberPoints.zero;
                            NumberPoints.zero *= 2;
                            thZero *= 2;
                            //prev0 = NumberPoints.zero - prev0;
                            num.transform.GetChild(0).GetChild(0).GetComponent<Text>().text = NumberPoints.zero.ToString();
                            //GameController.instance.UpdateBetInstant(0, prev0);
                        }
                        if (num.name == "1")
                        {
                            Debug.LogError("np 1" + NumberPoints.one);
                            prev1 = NumberPoints.one;
                            NumberPoints.one *= 2;
                            thOne *= 2;
                            //prev1 = NumberPoints.one - prev1;
                            num.transform.GetChild(0).GetChild(0).GetComponent<Text>().text = NumberPoints.one.ToString();
                            Debug.LogError("np 1 re" + NumberPoints.one);
                            
                        }
                        if (num.name == "2")
                        {
                            prev2 = NumberPoints.two;
                            NumberPoints.two *= 2;
                            thTwo *= 2;
                            //prev2 = NumberPoints.two - prev2;
                            num.transform.GetChild(0).GetChild(0).GetComponent<Text>().text = NumberPoints.two.ToString();
                           // GameController.instance.UpdateBetInstant(2, prev2);
                        }
                        if (num.name == "3")
                        {
                            prev3 = NumberPoints.three;
                            NumberPoints.three *= 2;
                            thThree *= 2;
                            //prev3 = NumberPoints.three - prev3;
                            num.transform.GetChild(0).GetChild(0).GetComponent<Text>().text = NumberPoints.three.ToString();
                            //GameController.instance.UpdateBetInstant(3, prev3);
                        }
                        if (num.name == "4")
                        {
                            prev4 = NumberPoints.four;
                            NumberPoints.four *= 2;
                            thFour *= 2;
                            //prev4 = NumberPoints.four - prev4;
                            num.transform.GetChild(0).GetChild(0).GetComponent<Text>().text = NumberPoints.four.ToString();
                            //GameController.instance.UpdateBetInstant(4, prev4);
                        }
                        if (num.name == "5")
                        {
                            prev5 = NumberPoints.five;
                            NumberPoints.five *= 2;
                            thFive *= 2;
                            //prev5 = NumberPoints.five - prev5;
                            num.transform.GetChild(0).GetChild(0).GetComponent<Text>().text = NumberPoints.five.ToString();
                           // GameController.instance.UpdateBetInstant(5, prev5);
                        }
                        if (num.name == "6")
                        {
                            prev6 = NumberPoints.six;
                            NumberPoints.six *= 2;
                            thSix *= 2;
                            //prev6 = NumberPoints.six - prev6;
                            num.transform.GetChild(0).GetChild(0).GetComponent<Text>().text = NumberPoints.six.ToString();
                            //GameController.instance.UpdateBetInstant(6, prev6);
                        }
                        if (num.name == "7")
                        {
                            prev7 = NumberPoints.seven;
                            NumberPoints.seven *= 2;
                            thSeven *= 2;
                            //prev7 = NumberPoints.seven - prev7;
                            num.transform.GetChild(0).GetChild(0).GetComponent<Text>().text = NumberPoints.seven.ToString();
                            //GameController.instance.UpdateBetInstant(7, prev7);
                        }
                        if (num.name == "8")
                        {
                            prev8 = NumberPoints.eight;
                            NumberPoints.eight *= 2;
                            thEight *= 2;
                            //prev8 = NumberPoints.eight - 8;
                            num.transform.GetChild(0).GetChild(0).GetComponent<Text>().text = NumberPoints.eight.ToString();
                            //GameController.instance.UpdateBetInstant(8, prev8);
                        }
                        if (num.name == "9")
                        {
                            prev9 = NumberPoints.nine;
                            NumberPoints.nine *= 2;
                            thNine *= 2;
                            // prev9 = NumberPoints.nine - prev9;
                            num.transform.GetChild(0).GetChild(0).GetComponent<Text>().text = NumberPoints.nine.ToString();
                            //GameController.instance.UpdateBetInstant(9, prev9);
                        }
                    }
                }
            }
            
            GameController.instance.UpdateBetInstant(0, 0);
            //popupmsg("Doubled");
        }
        else
        {
            ScreenFlowHandler.screenFlow.ShowErr();
            return;
        }
    }

    public void CancleDouble()
    {
        if(multiplication == 9 && !Is_Spinning)
        {
            multiplication = 9;
            DoubleTextWin.SetActive(false);
            DoubleTextPlay.SetActive(false);
            popupmsg("Cancled");
        }
        
    }

    IEnumerator GetWinNumber()
    {
        yield return new WaitForSeconds(3f);
        
        StartCoroutine(ResultView.resultView.RefreshLeftResultPanel());
        int check = Convert.ToInt32(gotNumber);
        Debug.Log("Checking for: " + check);
        foreach (int n in baitList)
            Debug.Log("The current list is: " + n);
        if (baitList.Contains(check))
        {
            Debug.Log("User won among list");
            StartCoroutine(GameController.instance.Setwin());
            SetWinandLossValues(true);
        }
        else
        {
            SetWinandLossValues(false);
        }
        if(numberFlashLight != null)
        {
            StopCoroutine(numberFlashLight);
        }

        numberFlashLight = StartCoroutine(ShowNumberWinReflect());
        WinDeclared = true;
        winaudio.Play();
        xNum.gameObject.SetActive(false);

    }


    Coroutine numberFlashLight;
    IEnumerator ShowNumberWinReflect()
    {
        BlackLayover.SetActive(true);
        foreach (Transform trn in allLightHolder)
        {
            trn.gameObject.GetComponent<Image>().color = new Color(255f, 255f, 255f, 1f);
        }
        while (true)
        {
            yield return new WaitForSeconds(.2f);
            foreach(Transform trn in allLightHolder)
            {
                trn.gameObject.GetComponent<Image>().color = Color.red;
            }
            yield return new WaitForSeconds(.2f);
            foreach (Transform trn in allLightHolder)
            {
                trn.gameObject.GetComponent<Image>().color = Color.yellow;
            }
            yield return new WaitForSeconds(.2f);
            foreach (Transform trn in allLightHolder)
            {
                trn.gameObject.GetComponent<Image>().color = Color.green;
            }
        }

        
    }

    void SetWinandLossValues(bool status)
    {
        int MainPointsNow = Convert.ToInt32(MainPoints.text);
        multiplication *= GameController.selectedXVal;

        if (status)
        switch (detect.LastObject.name)
        {
                

            case "0":
                MainPointsNow += NumberPoints.zero * multiplication;
                    tokensWon = NumberPoints.zero * multiplication;
                    won_on_number = 0;
                    //MainPointsNow -= Convert.ToInt32(PlayPoints.text);
                break;
            case "1":
                MainPointsNow += NumberPoints.one * multiplication;
                    tokensWon = NumberPoints.one * multiplication;
                    won_on_number = 1;
                    //MainPointsNow -= Convert.ToInt32(PlayPoints.text);
                break;
            case "2":
                MainPointsNow += NumberPoints.two * multiplication;
                    tokensWon = NumberPoints.two * multiplication;
                    won_on_number = 2;
                    //MainPointsNow -= Convert.ToInt32(PlayPoints.text);
                break;
            case "3":
                MainPointsNow += NumberPoints.three * multiplication;
                    tokensWon = NumberPoints.three * multiplication;
                    won_on_number = 3;
                   // MainPointsNow -= Convert.ToInt32(PlayPoints.text);
                break;
            case "4":
                MainPointsNow += NumberPoints.four * multiplication;
                    tokensWon = NumberPoints.four * multiplication;
                    won_on_number = 4;
                    //MainPointsNow -= Convert.ToInt32(PlayPoints.text);
                break;
            case "5":
                MainPointsNow += NumberPoints.five * multiplication;
                    tokensWon = NumberPoints.five * multiplication;
                    won_on_number = 5;
                    //MainPointsNow -= Convert.ToInt32(PlayPoints.text);
                break;
            case "6":
                MainPointsNow += NumberPoints.six * multiplication;
                    tokensWon = NumberPoints.six * multiplication;
                    won_on_number = 6;
                    //MainPointsNow -= Convert.ToInt32(PlayPoints.text);
                break;
            case "7":
                MainPointsNow += NumberPoints.seven * multiplication;
                    tokensWon = NumberPoints.seven * multiplication;
                    won_on_number = 7;
                    //MainPointsNow -= Convert.ToInt32(PlayPoints.text);
                break;
            case "8":
                MainPointsNow += NumberPoints.eight * multiplication;
                    tokensWon = NumberPoints.eight * multiplication;
                    won_on_number = 8;
                    //MainPointsNow -= Convert.ToInt32(PlayPoints.text);
                break;
            case "9":
                MainPointsNow += NumberPoints.nine * multiplication;
                    tokensWon = NumberPoints.nine * multiplication;
                    won_on_number = 9;
                    //MainPointsNow -= Convert.ToInt32(PlayPoints.text);
                        
                break;

        }
        else
        {
            //MainPointsNow -= Convert.ToInt32(PlayPoints.text);
            tokensWon = 0;
            won_on_number = -90;
        }

        multiplication = 9;
        //NAnim.enabled = true;
       NAnim.SetBool("Hit", true);
        NNumber.text = gotNumber.ToString();
        NNumber.gameObject.SetActive(true);
        MainPoints.text = MainPointsNow.ToString();

        if(status)
        Wintext.text =(Convert.ToInt32(Wintext.text) + tokensWon).ToString();

        GameObject obj = null;
        if (status)
        {
            //obj = BaitNumberPanelParent.transform.Find(detect.LastObject.name).gameObject;
            //obj.GetComponent<Animator>().SetBool("Play", true);
           
            popupmsg("+" + tokensWon.ToString());
            

        }
        DoubleTextWin.SetActive(false);
        DoubleTextPlay.SetActive(false);

        
        StartCoroutine(ShowWinOrLossMsg(obj));
        
        

    }

    IEnumerator ShowWinOrLossMsg(GameObject obj)
    {
        yield return new WaitForSeconds(1f);
        //popupmsg("-" + (Convert.ToInt32(PlayPoints.text)).ToString());
        if (Wintext.text != "0")
        {
            youWinMsg.SetActive(true);
            YouWinText.text = Wintext.text;
        }
        Glow.SetActive(true);
        yield return new WaitForSeconds(1f);
        GameController.TimerStarted = false;
        yield return new WaitForSeconds(2f);
        Glow.SetActive(false);
        if (obj != null)
        obj.GetComponent<Animator>().SetBool("Play", false);
        multiplication = 9;
        allowBait = true;
        Clear(NumberDrawPanel,true);
        if(numberFlashLight != null)
        {
            StopCoroutine(numberFlashLight);
            numberFlashLight = null;
        }

        foreach(Transform trn in allLightHolder)
        {
            trn.gameObject.GetComponent<Image>().color = new Color(255f, 255f, 255f, 0f);
        }

        BlackLayover.SetActive(false);
        GameController.instance.CheckSession();

    }

    public void popupmsg(string text)
    {
        return;
        GameObject obj = Instantiate(front_msg_text);
        obj.GetComponent<RectTransform>().SetParent(fmsg_parent);
        obj.GetComponent<RectTransform>().anchoredPosition = Vector2.zero;
        obj.GetComponent<RectTransform>().localScale = new Vector3(1f, 1f, 1f);
        obj.GetComponent<TextMeshProUGUI>().text = text;
        //obj.GetComponent<TextMeshProUGUI>().fontSize = 100f;
        
        Destroy(obj, 3f);
    }

    public void SetChipValue(GameObject Obj)
    {
        if(_GlobalChipHolder != null && Obj == _GlobalChipHolder)
        {
            return;
        }
        ChipSelected = true;
       
        ChipValue = Obj.GetComponent<HoldingValues>().Value;
        Obj.transform.parent.GetComponent<Image>().enabled = true;
        if(_GlobalChipHolder != null)
        {
            _GlobalChipHolder.transform.parent.GetComponent<Image>().enabled =false;
        }
        _GlobalChipHolder = Obj;
    }

    public void GetNumbersBait(GameObject num)
    {
        if(ChipSelected && allowBait)
        {

            if(ClearVal)
            {
                ClearVal = false;
                ClearNumber(num);
                return;
            }

            if (Convert.ToInt32(MainPoints.text) < ChipValue)
            {
                print("err");
                ScreenFlowHandler.screenFlow.ShowErr();
                return;
            }
            Debug.Log("Chip value is:"+ChipValue);
        MainPlayValue = Convert.ToInt32(PlayPoints.text);
        MainPlayValue += ChipValue;
        Text valTxt =  num.transform.GetChild(0).GetChild(0).gameObject.GetComponent<Text>();
        
        PlayPoints.text = MainPlayValue.ToString();
        MainPoints.text = (Convert.ToInt32(MainPoints.text) - ChipValue).ToString();
            // MainPoints.text = (Convert.ToInt32(MainPoints.text) - ChipValue).ToString();
            int selectedNum = -1;
        switch (num.name)
        {
            case "0": NumberPoints.zero+=ChipValue;
                    if(!baitList.Contains(0))
                        baitList.Add(0);
                    selectedNum = 0;
                    thZero += ChipValue;
                    valTxt.text = thZero.ToString();
                    break;
            case "1": NumberPoints.one+=ChipValue;
                    if (!baitList.Contains(1))
                        baitList.Add(1);
                    selectedNum = 1;
                    thOne += ChipValue;
                    valTxt.text = thOne.ToString();
                    break;
            case "2": NumberPoints.two+=ChipValue;
                    if (!baitList.Contains(2))
                        baitList.Add(2);
                    selectedNum = 2;
                    thTwo += ChipValue;
                    valTxt.text = thTwo.ToString();
                    break;
            case "3": NumberPoints.three+=ChipValue;
                    if (!baitList.Contains(3))
                        baitList.Add(3);
                    selectedNum = 3;
                    thThree += ChipValue;
                    valTxt.text = thThree.ToString();
                    break;
            case "4": NumberPoints.four+=ChipValue;
                    if (!baitList.Contains(4))
                        baitList.Add(4);
                    selectedNum = 4;
                    thFour += ChipValue;
                    valTxt.text = thFour.ToString();
                    break;
            case "5": NumberPoints.five+=ChipValue;
                    if (!baitList.Contains(5))
                        baitList.Add(5);
                    selectedNum = 5;
                    thFive += ChipValue;
                    valTxt.text = thFive.ToString();
                    break;
            case "6": NumberPoints.six+=ChipValue;
                    if (!baitList.Contains(6))
                        baitList.Add(6);
                    selectedNum = 6;
                    thSix += ChipValue;
                    valTxt.text = thSix.ToString();
                    break;
            case "7": NumberPoints.seven+=ChipValue;
                    if (!baitList.Contains(7))
                        baitList.Add(7);
                    selectedNum = 7;
                    thSeven += ChipValue;
                    valTxt.text = thSeven.ToString();
                    break;
            case "8": NumberPoints.eight+=ChipValue;
                    if (!baitList.Contains(8))
                        baitList.Add(8);
                    selectedNum = 8;
                    thEight += ChipValue;
                    valTxt.text = thEight.ToString();
                    break;
            case "9": NumberPoints.nine+=ChipValue;
                    if (!baitList.Contains(9))
                        baitList.Add(9);
                    selectedNum = 9;
                    thNine += ChipValue;
                    valTxt.text = thNine.ToString();
                    break;

        }
            if(sentState)
            GameController.instance.UpdateBetInstant(selectedNum,ChipValue);


        }
    }

    Coroutine Xcrt = null;

    public void SpinWheel()
    {
        //baitList.Clear();
        if(!Is_Spinning && GameController.has_network)
        {
            //if (Convert.ToInt32(PlayPoints.text) > Convert.ToInt32(MainPoints.text))
            //{
            //    ScreenFlowHandler.screenFlow.ShowErr();
            //    return;
            //}
            Is_Spinning = true;
            //_Speed = (float)UnityEngine.Random.Range(20, 30);
            _Speed = 500f;
            time = 0f;
            AllowRotation = true;
           Xcrt = StartCoroutine(ShowXVal());
            //SpinWheelAudio.Play();

        }

        
    }

    public IEnumerator ShowXVal()
    {
        float waitTime = .05f;
        int val = 1;
        int counter = 1;
        xNum.gameObject.SetActive(true);
        while(Is_Spinning)
        {
            yield return new WaitForSeconds(.3f);

            if (counter == 1)
            {
                //XNumber.text = "N";
                xNum.sprite = xNumns[counter];
            }
            else
            {
                //XNumber.text = counter + "X";
                xNum.sprite = xNumns[counter];

            }

            if(counter == 5)
            {
                counter = 0;
            }

            counter++;

            //waitTime += 0.05f;
        }
    }

    public void CLR(GameObject Traverse)
    {
        // Clear(Traverse);
        foreach (Transform trn in Traverse.transform)
        {
            trn.GetChild(0).GetChild(0).gameObject.GetComponent<Text>().text = "0";
        }

        NumberPoints.zero -= thZero; NumberPoints.one -= thOne; NumberPoints.two -= thTwo; NumberPoints.three -= thThree; NumberPoints.four -= thFour; NumberPoints.five -= thFive; NumberPoints.six -= thSix; NumberPoints.seven -= thSeven;
        NumberPoints.eight -= thEight; NumberPoints.nine -= thNine;

        int totalTemp = thZero + thOne + thTwo + thThree + thFour + thFive + thSix + thSeven + thEight + thNine;
        MainPlayValue -= totalTemp;

        thZero = 0; thOne = 0; thTwo = 0; thThree = 0; thFour = 0; thFive = 0; thSix = 0; thSeven = 0; thEight = 0; thNine = 0;

        int toal = NumberPoints.zero + NumberPoints.one + NumberPoints.two + NumberPoints.three + NumberPoints.four + NumberPoints.five + NumberPoints.six + NumberPoints.seven + NumberPoints.eight + NumberPoints.nine;

        if (toal <= 0)
            baitList.Clear();

        multiplication = 9;
        DoubleTextWin.SetActive(false);
        DoubleTextPlay.SetActive(false);

        GameController.instance.CheckRepeat();
        GameController.instance.UpdateBetInstant(0, 0);
    }


    public void Clear(GameObject Traverse, bool onlyClear = false, bool SpecialAccess = false)
    {
        if (!allowBait && !SpecialAccess)
        {
            return;
        }
        foreach (Transform trn in Traverse.transform)
        {
            trn.GetChild(0).GetChild(0).gameObject.GetComponent<Text>().text = "0";
        }
        //MainPoints.text = "1000";
        if (!onlyClear)
        {
            
            MainPoints.text = (Convert.ToInt32(MainPoints.text) + Convert.ToInt32(PlayPoints.text)).ToString();
        }
        
        PlayPoints.text = "0";
        MainPlayValue = 0;
        

        

        NumberPoints.zero = 0; NumberPoints.one = 0; NumberPoints.two = 0; NumberPoints.three = 0; NumberPoints.four = 0; NumberPoints.five = 0; NumberPoints.six = 0; NumberPoints.seven = 0;
        NumberPoints.eight = 0; NumberPoints.nine = 0;

        thZero = 0; thOne = 0; thTwo = 0; thThree = 0; thFour = 0; thFive = 0; thSix = 0; thSeven = 0; thEight = 0; thNine = 0;

        int toal = NumberPoints.zero + NumberPoints.one + NumberPoints.two + NumberPoints.three + NumberPoints.four + NumberPoints.five + NumberPoints.six + NumberPoints.seven + NumberPoints.eight + NumberPoints.nine;

        if(toal <= 0)
            baitList.Clear();
        
        multiplication = 9;
        DoubleTextWin.SetActive(false);
        DoubleTextPlay.SetActive(false);

        

    }

    public void Repeat()
    {
        if(!allowBait)
        {
            return;
        }

        if(Convert.ToInt32(MainPoints.text) < LastBait)
        {
            ScreenFlowHandler.screenFlow.ShowErr();
            return;
        }

        //Clear(NumberDrawPanel);

        foreach(KeyValuePair<string,int> numVal in  numberValues)
        {
            GameObject obj = GameObject.FindGameObjectWithTag(numVal.Key);
            obj.transform.GetChild(0).GetChild(0).GetComponent<Text>().text = numVal.Value.ToString();
            //obj.GetComponent<Button>().onClick.Invoke();
            MainPoints.text = (Convert.ToInt32(MainPoints.text) - numVal.Value).ToString();

            if (numVal.Key == "0")
            {
                NumberPoints.zero = Convert.ToInt32(numVal.Value);
                PlayPoints.text = (Convert.ToInt32(PlayPoints.text) + Convert.ToInt32(numVal.Value)).ToString();
                if (!baitList.Contains(0))
                    baitList.Add(0);

                
            }
            if (numVal.Key == "1")
            {
                NumberPoints.one = Convert.ToInt32(numVal.Value);
                PlayPoints.text = (Convert.ToInt32(PlayPoints.text) + Convert.ToInt32(numVal.Value)).ToString();
                if (!baitList.Contains(1))
                    baitList.Add(1);

                //GameController.instance.UpdateBetInstant(1, NumberPoints.one);
            }
            if (numVal.Key == "2")
            {
                NumberPoints.two = Convert.ToInt32(numVal.Value);
                PlayPoints.text = (Convert.ToInt32(PlayPoints.text) + Convert.ToInt32(numVal.Value)).ToString();
                if (!baitList.Contains(2))
                    baitList.Add(2);

               // GameController.instance.UpdateBetInstant(2, NumberPoints.two);
            }

            if (numVal.Key == "3")
            {
                NumberPoints.three = Convert.ToInt32(numVal.Value);
                PlayPoints.text = (Convert.ToInt32(PlayPoints.text) + Convert.ToInt32(numVal.Value)).ToString();
                if (!baitList.Contains(3))
                    baitList.Add(3);

               // GameController.instance.UpdateBetInstant(3, NumberPoints.three);
            }

            if (numVal.Key == "4")
            {
                NumberPoints.four = Convert.ToInt32(numVal.Value);
                PlayPoints.text = (Convert.ToInt32(PlayPoints.text) + Convert.ToInt32(numVal.Value)).ToString();
                if (!baitList.Contains(4))
                    baitList.Add(4);

                //GameController.instance.UpdateBetInstant(4, NumberPoints.four);
            }
            if (numVal.Key == "5")
            {
                NumberPoints.five = Convert.ToInt32(numVal.Value);
                PlayPoints.text = (Convert.ToInt32(PlayPoints.text) + Convert.ToInt32(numVal.Value)).ToString();
                if (!baitList.Contains(5))
                    baitList.Add(5);

                //GameController.instance.UpdateBetInstant(5, NumberPoints.five);
            }
            if (numVal.Key == "6")
            {
                NumberPoints.six = Convert.ToInt32(numVal.Value);
                PlayPoints.text = (Convert.ToInt32(PlayPoints.text) + Convert.ToInt32(numVal.Value)).ToString();
                if (!baitList.Contains(6))
                    baitList.Add(6);

                //GameController.instance.UpdateBetInstant(6, NumberPoints.six);
            }

            if (numVal.Key == "7")
            {
                NumberPoints.seven = Convert.ToInt32(numVal.Value);
                PlayPoints.text = (Convert.ToInt32(PlayPoints.text) + Convert.ToInt32(numVal.Value)).ToString();
                if (!baitList.Contains(7))
                    baitList.Add(7);

                //GameController.instance.UpdateBetInstant(7, NumberPoints.seven);
            }

            if (numVal.Key == "8")
            {
                NumberPoints.eight = Convert.ToInt32(numVal.Value);
                PlayPoints.text = (Convert.ToInt32(PlayPoints.text) + Convert.ToInt32(numVal.Value)).ToString();
                if (!baitList.Contains(8))
                    baitList.Add(8);

                //GameController.instance.UpdateBetInstant(8, NumberPoints.eight);
            }
            if (numVal.Key == "9")
            {
                NumberPoints.nine = Convert.ToInt32(numVal.Value);
                PlayPoints.text = (Convert.ToInt32(PlayPoints.text) + Convert.ToInt32(numVal.Value)).ToString();
                if (!baitList.Contains(9))
                    baitList.Add(9);

                //GameController.instance.UpdateBetInstant(9, NumberPoints.nine);
            }

        }

        GameController.instance.UpdateBetInstant(0, 0);
    }
    public void ClearParticularObject(GameObject obj)
    {

        string val = obj.transform.GetChild(0).gameObject.GetComponent<Text>().text;
        int number = Convert.ToInt32(val);
        if (number > 0)
        {

            number--;
            obj.transform.GetChild(0).gameObject.GetComponent<Text>().text = number.ToString();

        

        if (number == 0)
        {
                Debug.Log("Number shall be removed: " + obj.name);
                baitList.Remove(Convert.ToInt32(obj.name));
        }

        switch (obj.name)
        {
            case "0":
                   if(ChipValue <= NumberPoints.zero)
                    NumberPoints.zero -= ChipValue;
                    //baitList.Add(0);
                    
                break;
            case "1":
                    if (ChipValue <= NumberPoints.one)
                        NumberPoints.one -= ChipValue;
                //baitList.Add(1);
                break;
            case "2":
                    if (ChipValue <= NumberPoints.two)
                        NumberPoints.two -= ChipValue;
                //baitList.Add(2);
                break;
            case "3":
                    if (ChipValue <= NumberPoints.three)
                        NumberPoints.three -= ChipValue;
                //baitList.Add(3);
                break;
            case "4":
                    if (ChipValue <= NumberPoints.four)
                        NumberPoints.four -= ChipValue;
                //baitList.Add(4);
                break;
            case "5":
                    if (ChipValue <= NumberPoints.five)
                        NumberPoints.five -= ChipValue;
                // baitList.Add(5);
                break;
            case "6":
                    if (ChipValue <= NumberPoints.six)
                        NumberPoints.six -= ChipValue;
                // baitList.Add(6);
                break;
            case "7":
                    if (ChipValue <= NumberPoints.seven)
                        NumberPoints.seven -= ChipValue;
                // baitList.Add(7);
                break;
            case "8":
                    if (ChipValue <= NumberPoints.eight)
                        NumberPoints.eight -= ChipValue;
                // baitList.Add(8);
                break;
            case "9":
                    if (ChipValue <= NumberPoints.nine)
                        NumberPoints.nine -= ChipValue;
                // baitList.Add(9);
                break;
        }
            MainPlayValue = Convert.ToInt32(PlayPoints.text) - ChipValue;
            PlayPoints.text = (MainPlayValue).ToString();
        }
    }
}
