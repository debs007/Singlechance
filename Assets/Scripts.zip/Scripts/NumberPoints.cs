﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NumberPoints 
{
    public static int one,two,three,four,five,six,seven,eight,nine,zero;
}
